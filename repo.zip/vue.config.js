module.exports = {
    baseUrl: "/",
    publicPath: "/"
};
