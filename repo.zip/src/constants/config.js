
export const defaultLocale = "en";
export const localeOptions=[
    {id:'en',name:'English'},
    {id:'es',name:'Español'},
];
