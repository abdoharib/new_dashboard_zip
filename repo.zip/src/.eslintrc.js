module.exports = {
    rules: {
      "no-console": "off",
      "no-warning-comments": "off"
    }
  }
  